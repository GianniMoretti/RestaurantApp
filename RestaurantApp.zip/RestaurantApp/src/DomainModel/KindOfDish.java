package DomainModel;

public enum KindOfDish {
	STARTER,
	FIRST_COURSE,
	SECOND_COURSE,
	SIDE_DISH,
	PIZZA,
	DESSERT,
	DRINK
}
