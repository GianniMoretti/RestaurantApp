package DomainModel;

public class Waiter {
	private int waiterID;

	public Waiter(int waiterID) {
		this.waiterID = waiterID;
	}
}
