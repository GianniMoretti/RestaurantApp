package DomainModel;

public enum TableState {
	AVAILABLE,
	UNAVAILABLE,
	DIRTY,
	UNUSABLE
}
